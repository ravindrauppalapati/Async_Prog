﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ControlTaskResult
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine( "Enter Choice between 1 & 3 : ");
            string value = Console.ReadLine(); 
           
            SomeMethod(value);

            Console.Read();
        }
        public static async void SomeMethod(string value)
        { 
            var task = EvaluateValue(value);

            Console.WriteLine("Evaluate Started");
            try
            {
                Console.WriteLine($"Is IsCompleted : {task.IsCompleted}");   
                Console.WriteLine($"Is IsCancelled : {task.IsCanceled}");
                Console.WriteLine($"Is IsFaulted : {task.IsFaulted} ");

              var result =  await task;

                Console.WriteLine($"Result : {result}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Evaluate Completed");
        }

        private static Task<string> EvaluateValue(string value)
        {
            var TCS = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);

            if (value == "1")
            {
                TCS.SetResult("Task Completed");
            }
            else if (value == "2")
            {
                TCS.SetCanceled();
            }
            else
            {
                TCS.SetException(new ApplicationException($"Invalid Value : {value} "));
            }

            return TCS.Task;
        }
    }
}
