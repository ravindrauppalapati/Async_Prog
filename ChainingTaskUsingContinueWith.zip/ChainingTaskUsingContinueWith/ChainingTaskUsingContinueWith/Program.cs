﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainingTaskUsingContinueWith
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Task<string> task1 = Task.Run(() =>
            //{
            //    return 12;
            //}).ContinueWith(num => {
            //    return $"The Square of {num.Result} is : {num.Result * num.Result}";
            //});

            //Console.WriteLine(task1.Result);
            Task<int> task1 = Task.Run(() =>
            {
                return 10;
            });
            task1.ContinueWith(t => { Console.WriteLine("Task Cancelled"); },TaskContinuationOptions.OnlyOnCanceled);

            task1.ContinueWith(t => { Console.WriteLine("Task Faulted"); }, TaskContinuationOptions.OnlyOnFaulted);

            var result =  task1.ContinueWith(t => { Console.WriteLine("Task Completed"); }, TaskContinuationOptions.OnlyOnRanToCompletion);

            result.Wait();

            Console.ReadLine();
        }
    }
}
