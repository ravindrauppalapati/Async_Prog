﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SyncTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main Method Started....");
            Method1();
            Method2();
            Method3();
            Method4();
            Console.WriteLine("Main Method Completed....");

            Console.ReadLine();
        }
        public static Task Method1()
        {
            Console.WriteLine("Method 1 is Executing....");
            return Task.CompletedTask;
        }
        public static Task<string> Method2()
        {
            string name = "Hello";
            Console.WriteLine("Method 2 is Executing....");

            return Task.FromResult(name);
        }
        public static Task  Method3()
        {
            Console.WriteLine("Method 3 is Executing....");
            return Task.FromException(new ApplicationException());
        }
        public   static Task Method4()
        {
            Console.WriteLine("Method 4 is Executing....");

            CancellationTokenSource cts = new CancellationTokenSource(5000);
            cts.Cancel();
            return Task.FromCanceled(cts.Token);

        }
    }
}
