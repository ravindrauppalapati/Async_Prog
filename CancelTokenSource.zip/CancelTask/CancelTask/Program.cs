﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;
using System.Net.Http;
namespace CancelTask
{
    internal class Program
    {
        //https://localhost:7061/api/message/Ravi
        static void Main(string[] args)
        {
            //Method1();
            someMethod("Ravi");
            Console.ReadLine();
        }
        public static async void Method1()
        {
            int count = 10;
            Console.WriteLine("Method 1 Started");
            CancellationTokenSource cts = new CancellationTokenSource(5000);

            //Task task1 = Task.Run(() => { }, cts.Token);
            //Task task2 = Task.Run(() => { }, cts.Token);

            //cts.Cancel();

            //Timer timer = new Timer(_ => cts.Cancel(), null, TimeSpan.FromSeconds(5), Timeout.InfiniteTimeSpan);

            //Task.Run(() =>
            //{
            //    while (!cts.Token.IsCancellationRequested)
            //    {
            //        // task 
            //    }
            //}, cts.Token);
            //Task.Run(() =>
            //{
            //    for (int i = 0; i <= 10000; i++)
            //    {
            //        if (cts.Token.IsCancellationRequested)
            //        {
            //            return;
            //        }
            //    }

            //}, cts.Token);

            try 
            {
              await  LongRunningTask(count,cts.Token);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
            Console.WriteLine("Method 1 Stopped");
        }

        public static async Task LongRunningTask(int count, CancellationToken cts)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            Console.WriteLine("LongRunningTask Started");


            

            for (int i = 0;i<= count;i++)
            {
                await Task.Delay(1000);
                Console.WriteLine("LongRunningTask Processing");
                if(cts.IsCancellationRequested)
                {

                    throw new TaskCanceledException();
                }
            }

            stopwatch.Stop();
            Console.WriteLine($"LongRunningTask  {stopwatch.ElapsedMilliseconds/1000} sec for processing");
        }

        public async Task TaskName(CancellationToken cts)
        {
            while(!cts.IsCancellationRequested)
            {
                await Task.Delay(1000);
            }
        }

        public static async void someMethod(string Name)
        {
            Console.WriteLine("someMethod  Started");
            using (var client = new HttpClient())
            {
                CancellationTokenSource cts = new CancellationTokenSource(10000);
                client.BaseAddress = new Uri("https://localhost:7061/");

                try
                {
                    Console.WriteLine("SomeMethod Calling WebAPI");
                    HttpResponseMessage response = await client.GetAsync($"api/Message/{Name}", cts.Token);
                    string msg = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(msg);
                }
                catch (TaskCanceledException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.WriteLine("someMethod  Completed");
            }
        }
    }
}
