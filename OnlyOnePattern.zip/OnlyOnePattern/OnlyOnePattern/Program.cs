﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OnlyOnePattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
          OnlyOnePattern();
            Console.ReadLine();
        }


        //public static async void OnlyOnePattern()
        //{
        //    var cts = new CancellationTokenSource();
        //    List<string> listNames = new List<string> { "Lucky", "Honey", "Jaanu", "Sai", "Nishanth" };
        //    Console.WriteLine($"All Names");
        //    Console.WriteLine($"=======================");
        //    foreach (var item in listNames)
        //    {
        //        Console.Write($" {item} ");
        //    }
        //    var tasks = listNames.Select(x => SomeMethod(x, cts.Token));
        //    var task = await Task.WhenAny(tasks);
        //    var content = await task;
        //    cts.Cancel();
        //    Console.WriteLine($"\n {content}");
        //     }

            public static async Task<string> SomeMethod(string Name, CancellationToken token)
        {
            var waitingTime = new Random().NextDouble() * 10 + 1;
            await Task.Delay(TimeSpan.FromSeconds(waitingTime)); 
            string Message = $"Hello {Name}";
            return Message;
        }
        public static async void OnlyOnePattern()
        {   
            List<string> listNames = new List<string> { "Lucky", "Honey", "Jaanu", "Sai", "Nishanth" };
            Console.WriteLine($"All Names");
            Console.WriteLine($"=======================");
            foreach (var item in listNames)
            {
                Console.Write($" {item} ");
            }

            var tasks = listNames.Select(name =>
            {
                Func<CancellationToken, Task<string>> func = (ct) => SomeMethod(name, ct);
                return func;
            });

            var content =await GenericOnlyOnePattern(tasks);
            
            Console.WriteLine($"\n {content}");
        }

        public static async Task<T> GenericOnlyOnePattern<T>(IEnumerable<Func<CancellationToken, Task<T>>> function)
        {
             var cts= new CancellationTokenSource();
            var tasks = function.Select(fun => fun(cts.Token));
            var task = await Task.WhenAny(tasks);
            cts.Cancel();
            return await task; 
        }
    }
}
