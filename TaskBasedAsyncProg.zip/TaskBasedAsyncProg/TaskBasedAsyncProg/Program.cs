﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskBasedAsyncProg
{
    internal class Program
    {
        // task class & start Method
        //task object & factory property
        //task object & run method
        //task using wait
        //static  void Main(string[] args)
        //{
        //    Console.WriteLine($"Main Method : {Thread.CurrentThread.ManagedThreadId} started");

        //    //Action actionDlegate = new Action(PrintCounter); 

        //    //Task task1 = new Task(actionDlegate);
        //    //task1.Start();

        //    //Task task1 = Task.Factory.StartNew(PrintCounter);

        //    Task task1 = Task.Run(() =>
        //    {
        //        PrintCounter();
        //    });

        //    task1.Wait();

        //    Console.WriteLine($"Main Method : {Thread.CurrentThread.ManagedThreadId} Completed");
        //    Console.Read();
        //}
        static void Main(string[] args)
        {
            Console.WriteLine($"Main Method : {Thread.CurrentThread.ManagedThreadId} started");
            
            //=================Start Method======================

            Task task1 = new Task(PrintCounter);
            task1.Start();

            //Anonymous Method

            Task task2 = new Task(delegate ()
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
            });
            task2.Start();

            //Lambda Expression  

            Task task3 = new Task(() =>
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
            });
            task3.Start();
            //===============================Factory Property ( StartNew) ====================================
            Task task4 = Task.Factory.StartNew(PrintCounter);

            // Anonymous Method

            Task task5 = Task.Factory.StartNew(delegate ()
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
            });

            // Lambda Expression
            Task task6 = Task.Factory.StartNew(() =>
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
            });
            //============================Run Method() ==========================
            Task task7 = Task.Run(() => 
                {
                PrintCounter();
                });

            //Anonymous Method
            Task task8 = Task.Run(delegate ()
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
            });
            //Lambda Expression
            Task task9 = Task.Run(() =>
            {
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
                Task.Delay(200);
                Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");

            });

            Console.WriteLine($"Main Method : {Thread.CurrentThread.ManagedThreadId} Completed");

            Console.Read();

        }
        static void PrintCounter()
        {
            Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} started");
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"Count Value : {i}");
            }
            Console.WriteLine($"Child Method : {Thread.CurrentThread.ManagedThreadId} Completed");
        }   
    }
}
