﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AttachChildTaskToParentTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //##############   Detached Child Task ##########################
            //Console.WriteLine("Main Method Started");

            //var parentTask = Task.Factory.StartNew(() =>
            //{
            //    Console.WriteLine("Outer Task Started");
            //    var childTask = Task.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Child Task Started");
            //        Thread.Sleep(5000);
            //        Console.WriteLine("Child Task Completed");
            //    });
            //    Console.WriteLine("Outer Task Completed");
            //});
            //parentTask.Wait();
            //Console.WriteLine("Main Method Completed");
            //===============================================================
            //############### Parent Task will wait for Detached Task to complete Execution #############
            //Console.WriteLine("Main Method Started");

            //var parentTask = Task<string>.Factory.StartNew(() =>
            //{
            //    Console.WriteLine("Outer Task Started");
            //    var childTask = Task<string>.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Child Task Started");
            //        Thread.Sleep(5000);
            //        Console.WriteLine("Child Task Completed");
            //        return "Task Completed";
            //    });
            //    return childTask.Result;

            //   // Console.WriteLine("Outer Task Completed");
            //});
            ////  parentTask.Wait();
            //Console.WriteLine($"Parent Task Return Value :{parentTask.Result} ");
            //Console.WriteLine("Main Method Completed");
            //========================================================================================
            //############### Attached Child Task #############

            //Console.WriteLine("Main Method Started");

            //var parentTask = Task.Factory.StartNew(() =>
            //{
            //    Console.WriteLine("Outer Task Started");

            //    var childTask = Task.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Child Task Started");
            //        Thread.Sleep(5000);
            //        Console.WriteLine("Child Task Completed");
            //    },TaskCreationOptions.AttachedToParent); 

            //});
            //  parentTask.Wait(); 
            //Console.WriteLine("Main Method Completed");

            //==============================================================================================
            //############### Prevent Attached Child Task to Parent Task #############

            //Console.WriteLine("Main Method Started");

            //var parentTask = Task.Factory.StartNew(() =>
            //{
            //    Console.WriteLine("Outer Task Started");

            //    var childTask = Task.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Child Task Started");
            //        Thread.Sleep(5000);
            //        Console.WriteLine("Child Task Completed");
            //    }, TaskCreationOptions.AttachedToParent);

            //    Console.WriteLine("Outer Task Completed");
            //},TaskCreationOptions.DenyChildAttach);
            //parentTask.Wait();
            //Console.WriteLine("Main Method Completed");

            //============================================================================
            //Console.WriteLine("Main Method Started");

            //var parentTask = Task.Run(() =>
            //{
            //    Console.WriteLine("Outer Task Started");

            //    var childTask = Task.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Child Task Started");
            //        Thread.Sleep(5000);
            //        Console.WriteLine("Child Task Completed");
            //    }, TaskCreationOptions.AttachedToParent);

            //    Console.WriteLine("Outer Task Completed");
            //});

            //parentTask.Wait();
            //Console.WriteLine("Main Method Completed");
            //=============================================================================
            //############ Exception in Detached Task #############

            //Console.WriteLine("Main Method Started");
            //try
            //{
            //    var parentTask = Task.Factory.StartNew(() =>
            //    {
            //        Console.WriteLine("Outer Task Started");

            //        var childTask = Task.Factory.StartNew(() =>
            //        {
            //            Console.WriteLine("Child Task Started");
            //            int x = 10, y = 0;
            //            int z = x / y;
            //            Console.WriteLine("Child Task Completed");
            //        });

            //        Console.WriteLine("Outer Task Completed");
            //    });

            //    parentTask.Wait();

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Exception Occured : {ex.Message}");
            //}
            //Console.WriteLine("Main Method Completed");
            //==================================================================================
            //############ Exception in Attached Task #############

            Console.WriteLine("Main Method Started");
            try
            {
                var parentTask = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Outer Task Started");

                    var childTask = Task.Factory.StartNew(() =>
                    {
                        Console.WriteLine("Child Task Started");
                        int x = 10, y = 0;
                        int z = x / y;
                        Console.WriteLine("Child Task Completed");
                    }, TaskCreationOptions.AttachedToParent);

                    Console.WriteLine("Outer Task Completed");
                });

                parentTask.Wait();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occured : {ex.Message}");
            }
            Console.WriteLine("Main Method Completed");
            Console.ReadLine();
        }
    }
}
