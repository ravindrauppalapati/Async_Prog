﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetryPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main Method Started");
            RetryMethod(); 
            Console.WriteLine("Main Method Completed");
            Console.Read();
        }

        public static async void RetryMethod()
        {
            try
            {
             var Result = await  Retry(RetryOperation1);
               Console.WriteLine(Result);

                // Retry(RetryOperation2, 4);
            }
            catch (Exception ex)
            {
                Console.WriteLine("The Operation is Failed");
            } 
        }

        public static async Task<T> Retry<T>(Func<Task<T>> fun,int retryTimes = 3,int waitTime = 500)
        {
             
            for (int i = 0; i < retryTimes-1; i++)
            {
                try
                {
                    return  await fun(); 
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Retry : {i + 1} : Getting Exception : {ex.Message}");

                    await Task.Delay(waitTime);
                } 
            }
         return await fun();
        }
        

        public static async Task<string>  RetryOperation1()
        {
            await Task.Delay(500);

            return "Operation Success";
          //  throw new Exception("Exception Occured in RetryOperation1");
        }
        public static async Task  RetryOperation2()
        {
            await Task.Delay(500);

            throw new Exception("Exception Occured in RetryOperation2");
        }

    }
}
