﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueTaskinCSharp
{
    internal class Program
    {
        public static Dictionary<int, string> cardDic = new Dictionary<int, string>()
        {
            {101,"101 Card Info" },
             {102,"102 Card Info" },
             {103,"103 Card Info" },
             {104,"104 Card Info" }
        };

        static void Main(string[] args)
        {
            var card101 = getCardInfo(101);
            Console.WriteLine(card101);

            var card102 = getCardInfo(102);
            Console.WriteLine(card102);

            var card106 = getCardInfo(106);
            Console.WriteLine(card106);

            Console.Read();

        }
        public static async ValueTask<string> getCardInfo(int Id)
        {
            if (cardDic.ContainsKey(Id))
            {
                return cardDic[Id];
            }

            var card = $"card Info -{Id} from database";
             cardDic[Id] = card;

            return await Task.FromResult(card);
        }
    }
}
